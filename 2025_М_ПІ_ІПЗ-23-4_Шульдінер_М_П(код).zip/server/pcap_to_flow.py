import numpy as np
from scapy.all import IP, TCP, UDP

def get_flow_key(packet):
    if IP in packet:
        protocol = packet[IP].proto
        src_ip = packet[IP].src
        dst_ip = packet[IP].dst

        if protocol == 6 and TCP in packet:  # TCP
            sport = packet[TCP].sport
            dport = packet[TCP].dport
        elif protocol == 17 and UDP in packet:  # UDP
            sport = packet[UDP].sport
            dport = packet[UDP].dport
        else:
            sport, dport = 0, 0
    
        if (src_ip, sport) > (dst_ip, dport):
            return (dst_ip, dport, src_ip, sport, protocol)
        else:
            return (src_ip, sport, dst_ip, dport, protocol)
    return None

def calculate_iat(timestamps):
    if len(timestamps) < 2:
        return 0, 0, 0, 0
    iat = np.diff(timestamps)
    return iat.mean(), iat.std(), iat.max(), iat.min()

def extract_flow_features(packets):
    flows = {}
    for packet in packets:
        flow_key = get_flow_key(packet)
        if flow_key:
            if flow_key not in flows:
                flows[flow_key] = []
            flows[flow_key].append(packet)

    flow_features = []
    for flow_key, flow_packets in flows.items():
        if not flow_packets:
            continue

        flow_packets.sort(key=lambda p: p.time)
        
        flow_duration = (flow_packets[-1].time - flow_packets[0].time).total_seconds() * 1e6
        
        fwd_packets = [p for p in flow_packets if (p[IP].src, p[TCP].sport if TCP in p else (p[UDP].sport if UDP in p else 0)) == (flow_key[0], flow_key[1])]
        bwd_packets = [p for p in flow_packets if p not in fwd_packets]

        fwd_timestamps = [p.time for p in fwd_packets]
        bwd_timestamps = [p.time for p in bwd_packets]
        all_timestamps = sorted([p.time for p in flow_packets])

        flow_iat_mean, flow_iat_std, flow_iat_max, flow_iat_min = calculate_iat(all_timestamps)
        fwd_iat_total, (fwd_iat_mean, fwd_iat_std, fwd_iat_max, fwd_iat_min) = (sum(np.diff(fwd_timestamps)), calculate_iat(fwd_timestamps)) if len(fwd_timestamps) > 1 else (0, (0,0,0,0))
        bwd_iat_total, (bwd_iat_mean, bwd_iat_std, bwd_iat_max, bwd_iat_min) = (sum(np.diff(bwd_timestamps)), calculate_iat(bwd_timestamps)) if len(bwd_timestamps) > 1 else (0, (0,0,0,0))

        flow = {
            'Flow Duration': flow_duration,
            'Total Fwd Packets': len(fwd_packets),
            'Total Backward Packets': len(bwd_packets),
            'Fwd Packets Length Total': sum(len(p) for p in fwd_packets),
            'Bwd Packets Length Total': sum(len(p) for p in bwd_packets),
            'Flow Packets/s': len(flow_packets) / (flow_duration / 1e6) if flow_duration > 0 else 0,
            'Flow IAT Mean': flow_iat_mean,
            'Flow IAT Std': flow_iat_std,
            'Flow IAT Max': flow_iat_max,
            'Flow IAT Min': flow_iat_min,
            'Fwd IAT Total': fwd_iat_total,
            'Fwd IAT Mean': fwd_iat_mean,
            'Fwd IAT Std': fwd_iat_std,
            'Fwd IAT Max': fwd_iat_max,
            'Fwd IAT Min': fwd_iat_min,
            'Bwd IAT Total': bwd_iat_total,
            'Bwd IAT Mean': bwd_iat_mean,
            'Bwd IAT Std': bwd_iat_std,
            'Bwd IAT Max': bwd_iat_max,
            'Bwd IAT Min': bwd_iat_min,
            'Fwd PSH Flags': sum(1 for p in fwd_packets if TCP in p and 'P' in p[TCP].flags),
            'Bwd PSH Flags': sum(1 for p in bwd_packets if TCP in p and 'P' in p[TCP].flags),
            'Fwd URG Flags': sum(1 for p in fwd_packets if TCP in p and 'U' in p[TCP].flags),
            'Bwd URG Flags': sum(1 for p in bwd_packets if TCP in p and 'U' in p[TCP].flags),
            'Fwd Header Length': sum(p[IP].ihl * 4 for p in fwd_packets),
            'Bwd Header Length': sum(p[IP].ihl * 4 for p in bwd_packets),
            'Fwd Packets/s': len(fwd_packets) / (flow_duration / 1e6) if flow_duration > 0 else 0,
            'Bwd Packets/s': len(bwd_packets) / (flow_duration / 1e6) if flow_duration > 0 else 0,
            'SYN Flag Count': sum(1 for p in flow_packets if TCP in p and 'S' in p[TCP].flags),
            'RST Flag Count': sum(1 for p in flow_packets if TCP in p and 'R' in p[TCP].flags),
            'ACK Flag Count': sum(1 for p in flow_packets if TCP in p and 'A' in p[TCP].flags),
            'ECE Flag Count': sum(1 for p in flow_packets if TCP in p and 'E' in p[TCP].flags),
            'Down/Up Ratio': len(bwd_packets) / len(fwd_packets) if len(fwd_packets) > 0 else 0,
            'Init Fwd Win Bytes': fwd_packets[0][TCP].window if fwd_packets and TCP in fwd_packets[0] else -1,
            'Init Bwd Win Bytes': bwd_packets[0][TCP].window if bwd_packets and TCP in bwd_packets[0] else -1,
        }
        flow_features.append(flow)
        
    return flow_features 