from fastapi import FastAPI, File, UploadFile
from fastapi.responses import JSONResponse
from scapy.all import rdpcap
import tempfile
import os
from pcap_to_flow import extract_flow_features

app = FastAPI()

@app.post("/pcap-to-flow")
def pcap_to_flow_endpoint(file: UploadFile = File(...)):
    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        tmp.write(file.file.read())
        tmp_path = tmp.name
    try:
        packets = rdpcap(tmp_path)
        features = extract_flow_features(packets)
        return JSONResponse(content=features)
    finally:
        os.remove(tmp_path) 