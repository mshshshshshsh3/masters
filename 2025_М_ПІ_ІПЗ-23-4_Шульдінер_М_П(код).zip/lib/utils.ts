import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import type { PacketData } from "./types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Покращимо функцію formatTimestamp для коректної роботи з різними форматами timestamp
export function formatTimestamp(timestamp: number | string | Date): string {
  let date: Date;

  // Якщо рядок містить лише цифри, вважаємо його Unix timestamp
  if (typeof timestamp === "string" && /^\d+$/.test(timestamp)) {
    // Важливо перевірити довжину, оскільки JS Date розглядає timestamp у мілісекундах
    // Якщо timestamp у секундах, множимо на 1000
    date = new Date(
      timestamp.length === 10 ? parseInt(timestamp) * 1000 : parseInt(timestamp)
    );
  } else {
    date = new Date(timestamp);
  }

  // Перевіряємо валідність дати
  if (isNaN(date.getTime())) {
    return "Invalid Date";
  }

  return date.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    fractionalSecondDigits: 3,
  });
}

export function getProtocolName(protocol: number) {
  switch (protocol) {
    case 1:
      return "ICMP";
    case 6:
      return "TCP";
    case 17:
      return "UDP";
    default:
      return `Protocol ${protocol}`;
  }
}

export function ipToInt(ip: string) {
  try {
    const parts = ip.split(".");
    return (
      ((Number.parseInt(parts[0], 10) << 24) |
        (Number.parseInt(parts[1], 10) << 16) |
        (Number.parseInt(parts[2], 10) << 8) |
        Number.parseInt(parts[3], 10)) >>>
      0
    );
  } catch (e) {
    return 0;
  }
}

// Улучшенная функция для обнаружения SYN-флуд атак
export function detectSynFlood(
  packets: PacketData[],
  threshold: number = 0.3,
  timeWindow: number = 10,
  minSynCount: number = 10
): boolean {
  // Рахуємо SYN-пакети
  const synPackets = packets.filter((p) => p.flags.includes("S"));

  if (synPackets.length < minSynCount) {
    return false;
  }

  // Якщо більше 30% пакетів - SYN, це може бути флуд
  if (synPackets.length / packets.length > threshold) {
    return true;
  }

  // Перевірка на велику кількість SYN-пакетів до одного призначення за короткий час
  const synDestinations = new Map<string, number[]>();
  synPackets.forEach((p) => {
    if (!synDestinations.has(p.destIp)) {
      synDestinations.set(p.destIp, []);
    }
    synDestinations.get(p.destIp)!.push(new Date(p.timestamp).getTime());
  });

  for (const [destIp, timestamps] of synDestinations.entries()) {
    if (timestamps.length > 5) {
      // Якщо більше 5 SYN-пакетів на один IP
      const sortedTimestamps = timestamps.sort((a, b) => a - b);
      for (let i = 0; i <= sortedTimestamps.length - 5; i++) {
        if (sortedTimestamps[i + 4] - sortedTimestamps[i] < timeWindow * 1000) {
          return true;
        }
      }
    }
  }

  return false;
}
